<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Monika Sirotkovic</title>
  <style>
      html {
          color: #5b5d4b;
         background-color: white;
      }
      body {
        width: 80%;
        margin:auto;
          height: 720px;
          background-color:#d4daa9;
      }
    .container {
        margin-top: 50px;
       float: left;
      width: 50%;
      
      margin-bottom: 50px;
      margin-left: 50px;
      text-align: left;
      font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
      font-weight: bold;
      font-size: 20px;
      line-height:50px;
    }
    select {
      width: 100%;
      min-height: 150px;
      
      
    }
    input[type="submit"] {
      display: block;
      margin-top: 50px;
      padding: 20px;
      font-size: 17px;
      border: 0;
      color:white;
      background-color: #5b5d4b;
      border-radius: 25px;
    }
    label {
      display: block;
      position: relative;
      cursor: pointer;
      font-size: 22px;
      padding-left: 46px;
      margin-bottom: 25px;    
        
    
    }
    h1 {
        
        font-size: 25px;
    }
    label input {
      position: absolute;
      opacity: 0;
      cursor: pointer;
    }
    .select {
      top: 0;
      left: 0;
      height: 20px;
      width: 20px;
      position: absolute;
      border-radius: 50%;
      background-color: #5b5d4b;
      margin-top:14px;
    }
    label:hover input~.select {
      background-color: #edf4bf;
    }
    label input:checked~.select {
      background-color: white;
    }
   
  header{
      padding-top: 15px;
     
      padding-left:50px;
      height: 55px;
      background-color: #5b5d4b;
      color: white;
      font-size: 17px;
      font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
  }
 .right {
     float: right;
     width: 50%;
      margin-top: -600px ;
  
      margin-left: 50px;
      text-align: left;
      font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
      font-weight: bold;
      font-size: 20px;
     line-height: 45px;
    }
    
 
  </style>
</head>
<body>
    <header><h1>Odaberite vašu najdražu životinju </h1></header>
  <div class="container ">
    <form action="" method="post" class="mb-3">
      <label>
        <input type="radio" name="radio" value="Mačka">Mačka
        <span class="select"></span>
      </label>
      <label>
        <input type="radio" name="radio" value="Pas">Pas
        <span class="select"></span>
      </label>
      <label>
        <input type="radio" name="radio" value="Zec">Zec
        <span class="select"></span>
      </label>
      <label>
        <input type="radio" name="radio" value="Hrčak">Hrčak
        <span class="select"></span>
      </label>
      <label>
      <input type="radio" name="radio" value="Konj">Konj
        <span class="select"></span>
      </label>
      <label>
      <input type="radio" name="radio" value="Dupin">Dupin
        <span class="select"></span>
      </label>
      
      <input type="submit" name="submit" value="Saznaj karakteristike moje odabrane životinje">
    </form></div>

    <div class="right">
    <?php
    $xml_data = simplexml_load_file("xml_data.xml") or
    die("Error: Object Creation failure");
      if(isset($_POST['submit'])){
          $id=$_POST['radio'];
        if(!empty($_POST['radio'])) {
            if ($id == 'Mačka') {
                echo "<h2>" . $id . "</h2>";
                foreach ($xml_data->children() as $data)
                {
                    echo " Carstvo :", $data->macka->carstvo . "<br> ";
                    echo "Koljeno : ", $data->macka->koljeno . "<br> ";
                    echo "Vrsta : ", $data->macka->vrsta . "<br> ";
                    echo "Dužina : ", $data->macka->duzina . "<br> ";
                    echo "Težina : ", $data->macka->tezina . "<br> ";
                    echo "Životni vijek : ", $data->macka->zivotniVijek . "<br> ";
                  
                }
                    echo "<br>";}
           

            if ($id == 'Pas') {
                echo "<h2>" . $id . "</h2>";
                foreach ($xml_data->children() as $data)
                {
                    echo "Carstvo : ", $data->pas->carstvo . "<br> ";
                    echo "Koljeno : ", $data->pas->koljeno . "<br> ";
                    echo "Vrsta : ", $data->pas->vrsta . "<br> ";
                    echo "Dužina : ", $data->pas->duzina . "<br> ";
                    echo "Težina : ", $data->pas->tezina . "<br> ";
                    echo "Životni vijek : ", $data->pas->zivotniVijek . "<br> ";
                
                    echo "<br>";
            } }

              if ($id=='Zec') {
                echo "<h2>" . $id . "</h2>";
                foreach ($xml_data->children() as $data)
            {
                echo "Carstvo : ", $data->zec->carstvo . "<br> ";
                echo "Koljeno : ", $data->zec->koljeno . "<br> ";
                echo "Vrsta : ", $data->zec->vrsta . "<br> ";
                echo "Dužina : ", $data->zec->duzina . "<br> ";
                echo "Težina : ", $data->zec->tezina . "<br> ";
                echo "Životni vijek : ", $data->zec->zivotniVijek . "<br> ";
            
           
                echo "<br>";
            }}

            if ($id=='Hrčak') {
                echo "<h2>" . $id . "</h2>";
                foreach ($xml_data->children() as $data)
                {
                    echo "Carstvo : ", $data->hrcak->carstvo . "<br> ";
                    echo "Koljeno : ", $data->hrcak->koljeno . "<br> ";
                    echo "Vrsta : ", $data->hrcak->vrsta . "<br> ";
                    echo "Dužina : ", $data->hrcak->duzina . "<br> ";
                    echo "Težina : ", $data->hrcak->tezina . "<br> ";
                    echo "Životni vijek : ", $data->hrcak->zivotniVijek . "<br> ";
                
               
                    echo "<br>";
                }}

                if ($id=='Konj') {
                    echo "<h2>" . $id . "</h2>";
                    foreach ($xml_data->children() as $data)
                    {
                        echo "Carstvo : ", $data->konj->carstvo . "<br> ";
                        echo "Koljeno : ", $data->konj->koljeno . "<br> ";
                        echo "Vrsta : ", $data->konj->vrsta . "<br> ";
                        echo "Dužina : ", $data->konj->duzina . "<br> ";
                        echo "Težina : ", $data->konj->tezina . "<br> ";
                        echo "Životni vijek : ", $data->konj->zivotniVijek . "<br> ";
                    
                   
                        echo "<br>";
                    }}

                    if ($id=='Dupin') {
                        echo "<h2>" . $id . "</h2>";
                        foreach ($xml_data->children() as $data)
                        {
                            echo "Carstvo : ", $data->dupin->carstvo . "<br> ";
                            echo "Koljeno : ", $data->dupin->koljeno . "<br> ";
                            echo "Vrsta : ", $data->dupin->vrsta . "<br> ";
                            echo "Dužina : ", $data->dupin->duzina . "<br> ";
                            echo "Težina : ", $data->dupin->tezina . "<br> ";
                            echo "Životni vijek : ", $data->dupin->zivotniVijek . "<br> ";
                        
                       
                            echo "<br>";
                        }}
            }
            
          
        }
    
    

     
    ?>
    </div>

</body>
</html>